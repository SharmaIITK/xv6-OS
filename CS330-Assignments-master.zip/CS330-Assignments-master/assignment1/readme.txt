getppid:
In the function sys_getppid, we get the process calling the ecall by function myproc(),
